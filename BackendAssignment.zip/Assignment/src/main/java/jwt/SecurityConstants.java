package jwt;

public interface SecurityConstants {

	public static final String JWT_KEY ="secretprashantTiwari~king99~";
	public static final String JWT_HEADER ="Authorization";
}