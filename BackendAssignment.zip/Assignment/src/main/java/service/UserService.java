package service;

import exception.UserException;
import model.UserData;

public interface UserService {

	public UserData registerUser(UserData user) throws UserException;
	public UserData loginUser()  throws UserException;
}
